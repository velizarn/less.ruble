
function f() {
  'use strict';

  // No more octal
  var x = 42;

  // Duplicate property
  var y = { x: 1, y: 2 };

}